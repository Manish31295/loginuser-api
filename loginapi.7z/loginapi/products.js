   module.exports = [
{   "name": "Apple iPhone X",
    "category": "Cell Phone",
    "brand": "Apple",
    "model": "iPhone X",
    "price": 999,
    "quantity": 14
},
{
	"name": " Apple iPhone 8",
    "category": "Cell Phone",
    "brand": "Apple",
    "model": "iPhone 8",
    "price": 849,
    "quantity": 10
},
{
	"name": "Google Pixel 2 XL",
    "category": "Cell Phone",
    "brand": "Google",
    "model": "XL",
    "price": 649.99,
    "quantity": 10
},
{
	"name": "Google Pixel XL",
    "category": "Cell Phone",
    "brand": "Google",
    "model": "Pixel XL",
    "price": 414.99,
    "quantity": 11
},
{
	"name": "HTC U11",
    "category": "Cell Phone",
    "brand": "HTC",
    "model": "U11",
    "price": 572.97,
    "quantity": 11
},
{
	"name": "Volkswagen e-up! hatchback",
	"category": "Electric Car",
	"brand": "Volkswagen",
	"price": 25640,
	"quantity": 12
},
{
	"name": "Nissan Leaf hatchback",
	"category": "Electric Car",
	"brand": "Nissan",
	"price": 30990,
	"quantity": 12
},
{
	"name": "BMW i3 hatchback",
	"category": "Electric Car",
	"brand": "BMW",
	"price": 40125,
	"quantity": 12
},
{
	"name": "Kia Soul EV hatchback",
	"category": "Electric Car",
	"brand": "Kia Soul EV",
	"price": 30495,
	"quantity": 12
},
{
	"name": "Tesla Model X SUV",
	"category": "Electric Car",
	"brand": "Tesla",
	"price": 133185,
	"quantity": 12
}
]